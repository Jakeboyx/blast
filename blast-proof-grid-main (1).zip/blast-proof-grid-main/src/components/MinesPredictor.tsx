import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Pickaxe, Target, Hash, Zap } from "lucide-react";

interface PredictionResult {
  seed: string;
  safe_mines: number[];
  unsafe_mines: number[];
  grid: string[][];
}

const MinesPredictor = () => {
  const [step, setStep] = useState(1);
  const [safeMines, setSafeMines] = useState("");
  const [unsafeMines, setUnsafeMines] = useState("");
  const [seed, setSeed] = useState("");
  const [result, setResult] = useState<PredictionResult | null>(null);

  const generateGrid = () => {
    const safeCount = parseInt(safeMines);
    const unsafeCount = parseInt(unsafeMines);
    
    // Simple deterministic algorithm based on seed
    const seedHash = seed.split('').reduce((a, b) => {
      a = ((a << 5) - a) + b.charCodeAt(0);
      return a & a;
    }, 0);
    
    const positions = Array.from({ length: 25 }, (_, i) => i + 1);
    const safePositions: number[] = [];
    const unsafePositions: number[] = [];
    
    // Generate deterministic positions based on seed
    let rng = Math.abs(seedHash);
    
    // Select safe positions
    for (let i = 0; i < safeCount && positions.length > 0; i++) {
      rng = (rng * 9301 + 49297) % 233280;
      const index = rng % positions.length;
      safePositions.push(positions[index]);
      positions.splice(index, 1);
    }
    
    // Select unsafe positions
    for (let i = 0; i < unsafeCount && positions.length > 0; i++) {
      rng = (rng * 9301 + 49297) % 233280;
      const index = rng % positions.length;
      unsafePositions.push(positions[index]);
      positions.splice(index, 1);
    }
    
    // Create grid
    const grid: string[][] = [];
    for (let row = 0; row < 5; row++) {
      const gridRow: string[] = [];
      for (let col = 0; col < 5; col++) {
        const cellNumber = row * 5 + col + 1;
        let cellStatus = "🎚️"; // neutral
        
        if (safePositions.includes(cellNumber)) {
          cellStatus = "🟩";
        } else if (unsafePositions.includes(cellNumber)) {
          cellStatus = "❌";
        }
        
        gridRow.push(`${cellNumber}:${cellStatus}`);
      }
      grid.push(gridRow);
    }
    
    setResult({
      seed,
      safe_mines: safePositions.sort((a, b) => a - b),
      unsafe_mines: unsafePositions.sort((a, b) => a - b),
      grid
    });
  };

  const handleNextStep = () => {
    if (step === 1 && safeMines) {
      setStep(2);
    } else if (step === 2 && unsafeMines) {
      setStep(3);
    } else if (step === 3 && seed) {
      generateGrid();
      setStep(4);
    }
  };

  const resetPredictor = () => {
    setStep(1);
    setSafeMines("");
    setUnsafeMines("");
    setSeed("");
    setResult(null);
  };

  const getCellColor = (cell: string) => {
    if (cell.includes("🟩")) return "bg-safe text-primary-foreground";
    if (cell.includes("❌")) return "bg-unsafe text-destructive-foreground";
    return "bg-neutral text-accent-foreground";
  };

  return (
    <div className="min-h-screen bg-gradient-mining p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Pickaxe className="h-8 w-8 text-primary" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Mines Predictor
            </h1>
          </div>
          <p className="text-muted-foreground text-lg">
            Advanced 5×5 Mines game prediction system
          </p>
        </div>

        {step < 4 && (
          <Card className="shadow-card border-border/50 bg-card/50 backdrop-blur-sm">
            <CardHeader className="text-center">
              <CardTitle className="flex items-center justify-center gap-2">
                {step === 1 && <Target className="h-5 w-5 text-safe" />}
                {step === 2 && <Zap className="h-5 w-5 text-unsafe" />}
                {step === 3 && <Hash className="h-5 w-5 text-accent" />}
                Step {step} of 3
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {step === 1 && (
                <div className="space-y-4">
                  <div className="text-center">
                    <h3 className="text-xl font-semibold text-safe mb-2">
                      Safe Play Mines
                    </h3>
                    <p className="text-muted-foreground">
                      Please enter your SAFE play mines (1–8 recommended)
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="safe-mines">Number of Safe Mines</Label>
                    <Input
                      id="safe-mines"
                      type="number"
                      min="1"
                      max="8"
                      value={safeMines}
                      onChange={(e) => setSafeMines(e.target.value)}
                      placeholder="Enter safe mines count..."
                      className="text-center text-lg"
                    />
                  </div>
                </div>
              )}

              {step === 2 && (
                <div className="space-y-4">
                  <div className="text-center">
                    <h3 className="text-xl font-semibold text-unsafe mb-2">
                      Unsafe Mines
                    </h3>
                    <p className="text-muted-foreground">
                      ✅ That is your SAFE mines. Now please enter your UNSAFE mines (1–5)
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="unsafe-mines">Number of Unsafe Mines</Label>
                    <Input
                      id="unsafe-mines"
                      type="number"
                      min="1"
                      max="5"
                      value={unsafeMines}
                      onChange={(e) => setUnsafeMines(e.target.value)}
                      placeholder="Enter unsafe mines count..."
                      className="text-center text-lg"
                    />
                  </div>
                  <div className="text-center">
                    <Badge variant="secondary" className="bg-safe/20 text-safe">
                      Safe Mines: {safeMines}
                    </Badge>
                  </div>
                </div>
              )}

              {step === 3 && (
                <div className="space-y-4">
                  <div className="text-center">
                    <h3 className="text-xl font-semibold text-accent mb-2">
                      Seed Value
                    </h3>
                    <p className="text-muted-foreground">
                      Please enter your SEED (any number or word)
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="seed">Seed</Label>
                    <Input
                      id="seed"
                      value={seed}
                      onChange={(e) => setSeed(e.target.value)}
                      placeholder="Enter your seed..."
                      className="text-center text-lg"
                    />
                  </div>
                  <div className="flex justify-center gap-4">
                    <Badge variant="secondary" className="bg-safe/20 text-safe">
                      Safe: {safeMines}
                    </Badge>
                    <Badge variant="secondary" className="bg-unsafe/20 text-unsafe">
                      Unsafe: {unsafeMines}
                    </Badge>
                  </div>
                </div>
              )}

              <Button
                onClick={handleNextStep}
                className="w-full"
                size="lg"
                disabled={
                  (step === 1 && !safeMines) ||
                  (step === 2 && !unsafeMines) ||
                  (step === 3 && !seed)
                }
              >
                {step === 3 ? "Generate Prediction" : "Continue"}
              </Button>
            </CardContent>
          </Card>
        )}

        {result && step === 4 && (
          <div className="space-y-6">
            <Card className="shadow-card border-border/50 bg-card/50 backdrop-blur-sm">
              <CardHeader className="text-center">
                <CardTitle className="text-2xl text-primary">
                  🎯 Prediction Results
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                  <div>
                    <Badge variant="secondary" className="bg-accent/20 text-accent mb-2">
                      Seed
                    </Badge>
                    <p className="font-mono text-lg">{result.seed}</p>
                  </div>
                  <div>
                    <Badge variant="secondary" className="bg-safe/20 text-safe mb-2">
                      Safe Mines
                    </Badge>
                    <p className="font-mono text-lg">[{result.safe_mines.join(", ")}]</p>
                  </div>
                  <div>
                    <Badge variant="secondary" className="bg-unsafe/20 text-unsafe mb-2">
                      Unsafe Mines
                    </Badge>
                    <p className="font-mono text-lg">[{result.unsafe_mines.join(", ")}]</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-xl font-semibold text-center">5×5 Grid</h3>
                  <div className="grid grid-cols-5 gap-2 max-w-md mx-auto">
                    {result.grid.flat().map((cell, index) => (
                      <div
                        key={index}
                        className={`aspect-square rounded-lg flex items-center justify-center text-sm font-bold transition-all duration-300 hover:scale-105 ${getCellColor(cell)}`}
                      >
                        <span className="text-xs opacity-75">
                          {cell.split(":")[0]}
                        </span>
                        <span className="ml-1 text-lg">
                          {cell.split(":")[1]}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-secondary/50 rounded-lg p-4">
                  <h4 className="font-semibold mb-2">Legend:</h4>
                  <div className="flex flex-wrap gap-4 justify-center">
                    <div className="flex items-center gap-2">
                      <span className="text-lg">🟩</span>
                      <span className="text-safe">Safe Pick</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-lg">❌</span>
                      <span className="text-unsafe">Unsafe Mine</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-lg">🎚️</span>
                      <span className="text-neutral">Neutral Cell</span>
                    </div>
                  </div>
                </div>

                <Button
                  onClick={resetPredictor}
                  variant="outline"
                  className="w-full"
                  size="lg"
                >
                  New Prediction
                </Button>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};

export default MinesPredictor;