import MinesPredictor from "@/components/MinesPredictor";

const Index = () => {
  return <MinesPredictor />;
};

export default Index;
